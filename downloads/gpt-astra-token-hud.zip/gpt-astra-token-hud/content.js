(()=>{function D(t){if(t==null||t==="")return null;if(typeof t!="number"&&typeof t!="string")throw new Error("\u0E01\u0E23\u0E2D\u0E01\u0E07\u0E1A\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E15\u0E47\u0E21\u0E1A\u0E27\u0E01");if(typeof t=="string"&&!/^\d+$/.test(t))throw new Error("\u0E01\u0E23\u0E2D\u0E01\u0E07\u0E1A\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E15\u0E47\u0E21\u0E1A\u0E27\u0E01");let n=Number(t);if(!Number.isSafeInteger(n)||n<1||n>1e7)throw new Error("\u0E07\u0E1A\u0E15\u0E49\u0E2D\u0E07\u0E2D\u0E22\u0E39\u0E48\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07 1 \u0E16\u0E36\u0E07 10,000,000 \u0E42\u0E17\u0E40\u0E04\u0E19");return n}function T({used:t=null,messages:n=0,budget:r=null,status:s,note:o=""}){if(r=D(r),t!==null&&(!Number.isSafeInteger(t)||t<0))throw new Error("Invalid token count");let p=t===null||r===null?null:Math.max(0,r-t);return{status:s??(t===null?"waiting":"ready"),used:t,messages:n,budget:r,remaining:p,percent:p===null?null:p/r*100,updatedAt:t===null?null:Date.now(),note:o}}var J='[data-message-author-role="user"], [data-message-author-role="assistant"]',lt='button, svg, script, style, [hidden], [aria-hidden="true"], [data-token-hud-root], [data-testid="copy-turn-action-button"], [data-testid="thought-summary"], [data-testid="webpage-citation-pill"]',ct=new Set(["P","DIV","PRE","LI","H1","H2","H3","H4","H5","H6","TR","BLOCKQUOTE"]);function Q(t){if(t.closest('[hidden], [aria-hidden="true"]'))return!1;let n=t.ownerDocument.defaultView;for(let r=t;r;r=r.parentElement){let s=n.getComputedStyle(r);if(s.display==="none"||s.visibility==="hidden"||s.visibility==="collapse")return!1}return t.getClientRects().length>0||n.getComputedStyle(t).display==="contents"}function Y(t){if(t.nodeType===3)return t.nodeValue;if(t.nodeType!==1||t.matches(lt)||!Q(t))return"";if(t.tagName==="BR")return`
`;if(t.tagName==="DIV"&&t.querySelector("button")&&!t.querySelector("pre")&&t.parentElement?.querySelector("pre"))return"";let n=[...t.childNodes].map(Y).join("");return ct.has(t.tagName)?`${n}
`:n}function Z(t){return[...t.querySelectorAll(J)].filter(n=>!n.parentElement?.closest(J)&&Q(n)).map(n=>{let r=n.getAttribute("data-message-author-role"),s=n.querySelector("[data-message-content]"),o;return s?o=[s]:r==="user"?o=[n.querySelector(".whitespace-pre-wrap")??n]:(o=[...n.querySelectorAll(".markdown")].filter(p=>!p.parentElement?.closest(".markdown")),!o.length&&n.children.length===0&&(o=[n])),o.length?{element:n,role:r,text:o.map(Y).join(`
`).trim()}:null}).filter(Boolean)}var y=new Intl.NumberFormat("th-TH"),dt=0,ut=`
  :host {
    all: initial;
    position: fixed;
    top: 16px;
    right: 16px;
    z-index: 2147483647;
    display: block;
    color-scheme: dark;
    font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
    font-size: 13px;
    font-weight: 400;
    line-height: 1.5;
    direction: ltr;
    text-align: left;
  }
  *, *::before, *::after { box-sizing: border-box; }
  [hidden] { display: none !important; }
  .card {
    width: min(296px, calc(100vw - 32px));
    overflow: hidden;
    border: 1px solid #343d52;
    border-radius: 16px;
    background: #111722;
    color: #f3f6fc;
    box-shadow: 0 12px 36px #0006, 0 1px 0 #ffffff08 inset;
  }
  .header {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 11px 12px;
    border-bottom: 1px solid #ffffff0c;
  }
  .mark {
    display: grid;
    width: 25px;
    height: 25px;
    flex: 0 0 auto;
    place-items: center;
    border: 1px solid #43c8a85c;
    border-radius: 8px;
    background: #173a34;
    color: #78edc9;
    font-size: 16px;
    font-weight: 800;
  }
  .heading { flex: 1; min-width: 0; }
  .title {
    margin: 0;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .1em;
    white-space: nowrap;
  }
  .subtitle { margin: 0; color: #b7c2d5; font-size: 11px; }
  button, input { font: inherit; }
  button {
    border: 0;
    border-radius: 7px;
    cursor: pointer;
    transition: background .12s ease, border-color .12s ease;
  }
  button:focus-visible, input:focus-visible {
    outline: 2px solid #83e6c9;
    outline-offset: 3px;
  }
  .icon-button {
    display: grid;
    width: 28px;
    height: 28px;
    flex: 0 0 auto;
    place-items: center;
    padding: 0;
    background: transparent;
    color: #b7c2d5;
    font-size: 17px;
  }
  .icon-button:hover { background: #ffffff12; color: #fff; }
  .body { padding: 13px 14px 12px; }
  .balance-label { margin: 0 0 2px; color: #c7d1e3; font-size: 12px; }
  .balance {
    margin: 0;
    color: #f3f6fc;
    font-size: 26px;
    font-weight: 750;
    font-variant-numeric: tabular-nums;
    letter-spacing: -.025em;
    line-height: 1.3;
    overflow-wrap: anywhere;
  }
  .balance.unknown { font-size: 21px; }
  .capacity { margin: 3px 0 10px; color: #a7b4cc; font-size: 11px; }
  .meter {
    height: 11px;
    overflow: hidden;
    border: 1px solid #ffffff0d;
    border-radius: 5px;
    background: #283346;
  }
  .fill {
    width: 0;
    height: 100%;
    border-radius: 3px;
    background: #6ee7b7;
    box-shadow: 0 0 10px #6ee7b73d inset;
    transition: width .24s ease, background .18s ease;
  }
  .meter[data-tone="warning"] .fill { background: #f4c55a; }
  .meter[data-tone="danger"] .fill { background: #fb7884; }
  .meter[data-tone="unknown"] {
    background: repeating-linear-gradient(135deg, #253043 0 7px, #303c50 7px 14px);
  }
  .meter[data-tone="unknown"] .fill { display: none; }
  .usage {
    margin: 8px 0 0;
    color: #b7c2d5;
    font-size: 11px;
    font-variant-numeric: tabular-nums;
  }
  .note { margin: 8px 0 0; color: #c7d1e3; font-size: 11px; overflow-wrap: anywhere; }
  .footnote {
    margin: 10px 0 0;
    padding-top: 9px;
    border-top: 1px solid #ffffff0b;
    color: #a8b6cc;
    font-size: 10px;
    line-height: 1.5;
  }
  .time { margin: 3px 0 0; color: #8f9eb6; font-size: 10px; }
  .compact {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 9px 12px;
    color: #d9e3f4;
    font-size: 12px;
    font-variant-numeric: tabular-nums;
  }
  .compact-dot { width: 7px; height: 7px; border-radius: 50%; background: #a7b4cc; }
  .compact-note { margin: 0; padding: 0 12px 10px; color: #a8b6cc; font-size: 10px; }
  .settings {
    padding: 13px 14px 14px;
    border-top: 1px solid #3b4960;
    background: #182130;
  }
  .settings-title { margin: 0 0 5px; font-size: 13px; font-weight: 700; }
  .settings-help { margin: 0 0 12px; color: #c7d1e3; font-size: 11px; }
  label { display: block; margin-bottom: 5px; color: #d9e3f4; font-size: 12px; }
  input {
    width: 100%;
    min-width: 0;
    height: 36px;
    padding: 7px 10px;
    border: 1px solid #53617a;
    border-radius: 8px;
    background: #101722;
    color: #f3f6fc;
    font-size: 14px;
    font-variant-numeric: tabular-nums;
  }
  input[aria-invalid="true"] { border-color: #fb7884; }
  .input-help { margin: 5px 0 11px; color: #a8b6cc; font-size: 10px; }
  .actions { display: flex; gap: 8px; }
  .save, .clear { min-height: 33px; padding: 6px 12px; font-size: 12px; font-weight: 650; }
  .save { flex: 1; background: #75e0c1; color: #102b26; }
  .save:hover { background: #93efd5; }
  .clear { border: 1px solid #4c5a72; background: transparent; color: #d9e3f4; }
  .clear:hover { background: #ffffff0a; }
  button:disabled { cursor: wait; opacity: .6; }
  .feedback { margin: 9px 0 0; color: #ffadb6; font-size: 11px; overflow-wrap: anywhere; }
  .feedback[data-kind="success"] { color: #9ce7ce; }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { transition: none !important; }
  }
  @media (max-width: 400px) {
    :host { top: 10px; right: 10px; }
    .card { width: min(276px, calc(100vw - 20px)); }
  }
`;function a(t,n={},r=[]){let s=document.createElement(t);for(let[o,p]of Object.entries(n))o==="text"?s.textContent=p:o==="className"?s.className=p:s.setAttribute(o,String(p));return s.append(...r),s}function P(t){return Number.isSafeInteger(t)&&t>=0}function tt(t){return P(t)&&t>0&&t<=1e7}function et({onBudgetChange:t}={}){let n=`astra-token-hud-${++dt}`,r=a("div",{"data-astra-token-hud":""}),s=r.attachShadow({mode:"open"}),o=a("style",{text:ut}),p=a("p",{className:"title",text:"ASTRA \xB7 TOKENS"}),E=a("p",{className:"subtitle",text:"\u0E07\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E42\u0E14\u0E22\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13"}),b=a("button",{type:"button",className:"icon-button",text:"\u2699",title:"\u0E15\u0E31\u0E49\u0E07\u0E07\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19","aria-label":"\u0E15\u0E31\u0E49\u0E07\u0E07\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19","aria-expanded":"false","aria-controls":`${n}-settings`}),d=a("button",{type:"button",className:"icon-button",text:"\u2212",title:"\u0E22\u0E48\u0E2D\u0E41\u0E16\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19","aria-label":"\u0E22\u0E48\u0E2D\u0E41\u0E16\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19","aria-expanded":"true","aria-controls":`${n}-body`}),x=a("div",{className:"header"},[a("span",{className:"mark",text:"\u2726","aria-hidden":"true"}),a("div",{className:"heading"},[p,E]),b,d]),M=a("p",{className:"balance-label",text:"\u0E07\u0E1A\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13"}),I=a("p",{className:"balance unknown",text:"\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E17\u0E23\u0E32\u0E1A"}),u=a("p",{className:"capacity",text:"\u0E15\u0E31\u0E49\u0E07\u0E07\u0E1A\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E31\u0E27\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E41\u0E2A\u0E14\u0E07\u0E2B\u0E25\u0E2D\u0E14\u0E1E\u0E25\u0E31\u0E07"}),c=a("div",{className:"fill"}),m=a("div",{className:"meter",role:"progressbar","aria-label":"\u0E07\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E17\u0E23\u0E32\u0E1A","aria-valuemin":"0","aria-valuemax":"100","data-tone":"unknown"},[c]),k=a("p",{className:"usage",text:"\u0E43\u0E0A\u0E49\u0E44\u0E1B\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13: \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E17\u0E23\u0E32\u0E1A"}),v=a("p",{className:"note"});v.hidden=!0;let l=a("p",{className:"time"});l.hidden=!0;let f=a("div",{className:"body",id:`${n}-body`},[M,I,u,m,k,v,a("p",{className:"footnote",text:"\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13\u0E08\u0E32\u0E01\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E47\u0E19 \xB7 \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E42\u0E04\u0E27\u0E15\u0E32\u0E1A\u0E31\u0E0D\u0E0A\u0E35 GPT"}),l]),$=a("span",{className:"compact-dot","aria-hidden":"true"}),W=a("span",{text:"\u0E07\u0E1A\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13: \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E17\u0E23\u0E32\u0E1A"}),R=a("div",{className:"compact"},[$,W]);R.hidden=!0;let q=a("p",{className:"compact-note",text:"\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E47\u0E19 \xB7 \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E42\u0E04\u0E27\u0E15\u0E32\u0E1A\u0E31\u0E0D\u0E0A\u0E35 GPT"});q.hidden=!0;let g=a("input",{id:`${n}-budget`,type:"number",inputmode:"numeric",min:"1",max:String(1e7),step:"1",placeholder:"\u0E40\u0E0A\u0E48\u0E19 10000",autocomplete:"off","aria-describedby":`${n}-help ${n}-feedback`}),F=a("button",{type:"submit",className:"save",text:"\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E07\u0E1A"}),_=a("button",{type:"button",className:"clear",text:"\u0E25\u0E49\u0E32\u0E07\u0E07\u0E1A"}),z=a("p",{className:"feedback",id:`${n}-feedback`,role:"status","aria-live":"polite"});z.hidden=!0;let N=a("form",{className:"settings",id:`${n}-settings`,"aria-label":"\u0E15\u0E31\u0E49\u0E07\u0E07\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E31\u0E27",novalidate:""},[a("p",{className:"settings-title",text:"\u0E15\u0E31\u0E49\u0E07\u0E07\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E31\u0E27"}),a("p",{className:"settings-help",text:"\u0E2B\u0E25\u0E2D\u0E14\u0E19\u0E35\u0E49\u0E40\u0E17\u0E35\u0E22\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E21\u0E2D\u0E07\u0E40\u0E2B\u0E47\u0E19\u0E01\u0E31\u0E1A\u0E07\u0E1A\u0E17\u0E35\u0E48\u0E04\u0E38\u0E13\u0E15\u0E31\u0E49\u0E07\u0E40\u0E2D\u0E07 \u0E2D\u0E48\u0E32\u0E19\u0E22\u0E2D\u0E14\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E2B\u0E23\u0E37\u0E2D\u0E42\u0E04\u0E27\u0E15\u0E32\u0E08\u0E23\u0E34\u0E07\u0E02\u0E2D\u0E07\u0E1A\u0E31\u0E0D\u0E0A\u0E35 GPT \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49"}),a("label",{for:`${n}-budget`,text:"\u0E07\u0E1A\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 (\u0E42\u0E17\u0E40\u0E04\u0E19)"}),g,a("p",{className:"input-help",id:`${n}-help`,text:"\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E15\u0E47\u0E21 1\u201310,000,000 \xB7 \u0E43\u0E0A\u0E49\u0E40\u0E1B\u0E47\u0E19\u0E07\u0E1A\u0E02\u0E2D\u0E07\u0E1A\u0E17\u0E2A\u0E19\u0E17\u0E19\u0E32\u0E19\u0E35\u0E49"}),a("div",{className:"actions"},[F,_]),z]);N.hidden=!0;let at=a("section",{className:"card","aria-label":"GPT Astra \u0E07\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19\u0E42\u0E14\u0E22\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13"},[x,f,R,q,N]);s.append(o,at),document.documentElement.append(r);let S=!1,G=!1,h=!1,H=null,O=!1;function A(e,i="error"){z.textContent=e,z.dataset.kind=i,z.hidden=!e}function X(e){N.hidden=!e,b.setAttribute("aria-expanded",String(e)),e&&(O||(g.value=H===null?"":String(H)),g.focus())}async function j(e){if(!(G||S)){if(typeof t!="function"){A("\u0E22\u0E31\u0E07\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E07\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E42\u0E2B\u0E25\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E43\u0E2B\u0E21\u0E48");return}G=!0,g.disabled=!0,F.disabled=!0,_.disabled=!0,A(""),g.removeAttribute("aria-invalid");try{if(await t(e),S)return;H=e,O=!1,g.value=e===null?"":String(e),A(e===null?"\u0E25\u0E49\u0E32\u0E07\u0E07\u0E1A\u0E41\u0E25\u0E49\u0E27":"\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E07\u0E1A\u0E41\u0E25\u0E49\u0E27","success")}catch(i){if(S)return;N.hidden=!1,b.setAttribute("aria-expanded","true");let w=i instanceof Error&&i.message?`: ${i.message}`:"";A(`\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E07\u0E1A\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08${w}`)}finally{S||(G=!1,g.disabled=!1,F.disabled=!1,_.disabled=!1)}}}b.addEventListener("click",()=>X(N.hidden)),d.addEventListener("click",()=>{h=!h,f.hidden=h,R.hidden=!h,q.hidden=!h,d.textContent=h?"+":"\u2212";let e=h?"\u0E02\u0E22\u0E32\u0E22\u0E41\u0E16\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19":"\u0E22\u0E48\u0E2D\u0E41\u0E16\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19";d.title=e,d.setAttribute("aria-label",e),d.setAttribute("aria-expanded",String(!h)),h&&X(!1)}),g.addEventListener("input",()=>{O=!0,g.removeAttribute("aria-invalid"),A("")}),N.addEventListener("submit",e=>{e.preventDefault();let i=g.value.trim(),w=Number(i);if(!/^\d+$/.test(i)||!tt(w)){g.setAttribute("aria-invalid","true"),A("\u0E01\u0E23\u0E2D\u0E01\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E15\u0E47\u0E21\u0E15\u0E31\u0E49\u0E07\u0E41\u0E15\u0E48 1 \u0E16\u0E36\u0E07 10,000,000"),g.focus();return}j(w)}),_.addEventListener("click",()=>{j(null)}),s.addEventListener("keydown",e=>{e.key==="Escape"&&!N.hidden&&(e.preventDefault(),e.stopPropagation(),X(!1),b.focus())});function rt(e={}){if(S)return;let i=tt(e.budget)?e.budget:null,w=P(e.used)?e.used:null,C=P(e.remaining)&&i!==null&&e.remaining<=i?e.remaining:null,B=e.status==="ready"&&i!==null&&w!==null&&C!==null,ot=P(e.messages)?e.messages:0;if(H=i,!O&&!G&&(g.value=i===null?"":String(i)),I.textContent=B?y.format(C):"\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E17\u0E23\u0E32\u0E1A",I.classList.toggle("unknown",!B),M.textContent="\u0E07\u0E1A\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13",u.textContent=B?`/ ${y.format(i)} \u0E42\u0E17\u0E40\u0E04\u0E19\u0E17\u0E35\u0E48\u0E15\u0E31\u0E49\u0E07\u0E44\u0E27\u0E49`:i===null?"\u0E15\u0E31\u0E49\u0E07\u0E07\u0E1A\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E31\u0E27\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E41\u0E2A\u0E14\u0E07\u0E2B\u0E25\u0E2D\u0E14\u0E1E\u0E25\u0E31\u0E07":`\u0E07\u0E1A\u0E17\u0E35\u0E48\u0E15\u0E31\u0E49\u0E07\u0E44\u0E27\u0E49 ${y.format(i)} \u0E42\u0E17\u0E40\u0E04\u0E19`,k.textContent=`${w===null?"\u0E43\u0E0A\u0E49\u0E44\u0E1B\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13: \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E17\u0E23\u0E32\u0E1A":`\u0E43\u0E0A\u0E49\u0E44\u0E1B\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13 ${y.format(w)} \u0E42\u0E17\u0E40\u0E04\u0E19`} \xB7 ${y.format(ot)} \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21`,W.textContent=B?`\u0E07\u0E1A\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13 ${y.format(C)} / ${y.format(i)}`:"\u0E07\u0E1A\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13: \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E17\u0E23\u0E32\u0E1A",B){let U=Math.max(0,Math.min(100,typeof e.percent=="number"&&Number.isFinite(e.percent)?e.percent:C/i*100)),V=U<=20?"danger":U<=50?"warning":"healthy",st=V==="danger"?"#fb7884":V==="warning"?"#f4c55a":"#6ee7b7";m.dataset.tone=V,m.setAttribute("aria-valuenow",String(Math.round(U))),m.setAttribute("aria-valuetext",`\u0E07\u0E1A\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13 ${y.format(C)} \u0E08\u0E32\u0E01 ${y.format(i)} \u0E42\u0E17\u0E40\u0E04\u0E19`),m.setAttribute("aria-label","\u0E07\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E31\u0E27\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E42\u0E14\u0E22\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13"),c.style.width=`${U}%`,$.style.background=st}else m.dataset.tone="unknown",m.removeAttribute("aria-valuenow"),m.removeAttribute("aria-valuetext"),m.setAttribute("aria-label","\u0E07\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E17\u0E23\u0E32\u0E1A"),c.style.width="0%",$.style.background="#a7b4cc";let it=e.status==="error"?"\u0E2D\u0E48\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E25\u0E2D\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E43\u0E2B\u0E21\u0E48":e.status==="unsupported"?"\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E35\u0E49\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E01\u0E32\u0E23\u0E2D\u0E48\u0E32\u0E19\u0E1A\u0E17\u0E2A\u0E19\u0E17\u0E19\u0E32":e.status==="waiting"?"\u0E23\u0E2D\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E43\u0E19\u0E1A\u0E17\u0E2A\u0E19\u0E17\u0E19\u0E32\u2026":"";v.textContent=typeof e.note=="string"&&e.note.trim()?e.note:it,v.hidden=!v.textContent;let K=typeof e.updatedAt=="number"&&Number.isFinite(e.updatedAt)?new Date(e.updatedAt):null;K&&!Number.isNaN(K.getTime())?(l.textContent=`\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15 ${K.toLocaleTimeString("th-TH",{hour:"2-digit",minute:"2-digit"})}`,l.hidden=!1):(l.textContent="",l.hidden=!0)}return{host:r,update:rt,destroy(){S||(S=!0,r.remove())}}}var L="gptAstraTokenHudSettings",nt="gpt-astra-token-hud";async function pt(){if(document.getElementById(nt))return;let t=null,n="";try{let u=await chrome.storage.local.get(L);t=D(u[L]?.budget)}catch{n="\u0E2D\u0E48\u0E32\u0E19\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E40\u0E1B\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E07\u0E1A\u0E43\u0E2B\u0E21\u0E48"}let r=new WeakMap,s=location.pathname,o="",p,E=!1,b=!1,d=et({async onBudgetChange(u){let c=D(u);await chrome.storage.local.set({[L]:{budget:c}}),t=c,n="",o="",x()}});d.host.id=nt,d.host.setAttribute("data-token-hud-root",""),d.update(T({budget:t,note:"\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2D\u0E48\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32"}));function x(){b=!0,!p&&!E&&(p=setTimeout(M,250))}async function M(){if(p=void 0,E)return;E=!0,b=!1;let u=location.pathname;try{d.host.isConnected||document.documentElement.append(d.host),u!==s&&(r=new WeakMap,o="",s=u,d.update(T({budget:t,note:"\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2D\u0E48\u0E32\u0E19\u0E41\u0E0A\u0E15\u0E43\u0E2B\u0E21\u0E48"})));let c=Z(document),m=JSON.stringify([u,t,c.map(({role:l,text:f})=>[l,f])]);if(m===o)return;if(c.length===0){d.update(T({budget:t,status:u.startsWith("/codex")?"unsupported":"waiting",note:n||(u.startsWith("/codex")?"\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E35\u0E49\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E1C\u0E22\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E15\u0E31\u0E27\u0E19\u0E31\u0E1A\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E14\u0E49":"\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E0A\u0E15\u0E17\u0E35\u0E48\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E14\u0E49")})),o=m;return}let k=c.filter(l=>r.get(l.element)?.text!==l.text);if(k.length){let l=await chrome.runtime.sendMessage({type:"GPT_ASTRA_COUNT_TOKENS",texts:k.map(f=>f.text)});if(!l?.ok||!Array.isArray(l.counts)||l.counts.length!==k.length||l.counts.some(f=>!Number.isSafeInteger(f)||f<0))throw new Error(l?.error||"\u0E15\u0E31\u0E27\u0E19\u0E31\u0E1A\u0E42\u0E17\u0E40\u0E04\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21");if(location.pathname!==u){b=!0;return}k.forEach((f,$)=>r.set(f.element,{text:f.text,count:l.counts[$]}))}let v=c.reduce((l,f)=>l+r.get(f.element).count,0);d.update(T({used:v,messages:c.length,budget:t,note:n||"\u0E19\u0E31\u0E1A\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E42\u0E2B\u0E25\u0E14\u0E43\u0E19\u0E41\u0E0A\u0E15\u0E19\u0E35\u0E49 \u0E44\u0E21\u0E48\u0E23\u0E27\u0E21\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E41\u0E25\u0E30\u0E1A\u0E23\u0E34\u0E1A\u0E17\u0E17\u0E35\u0E48\u0E0B\u0E48\u0E2D\u0E19"})),o=m}catch(c){d.update(T({budget:t,status:"error",note:c.message})),o=""}finally{E=!1,b&&x()}}new MutationObserver(u=>{u.some(c=>c.target!==d.host&&!d.host.contains(c.target))&&x()}).observe(document.documentElement,{childList:!0,characterData:!0,subtree:!0,attributes:!0,attributeFilter:["data-message-author-role","hidden","aria-hidden","style","class"]}),setInterval(x,1e3),chrome.storage.onChanged.addListener((u,c)=>{if(!(c!=="local"||!u[L]))try{t=D(u[L].newValue?.budget),o="",x()}catch{t=null,n="\u0E07\u0E1A\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E27\u0E49\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E15\u0E31\u0E49\u0E07\u0E43\u0E2B\u0E21\u0E48",o="",x()}}),x()}pt().catch(t=>console.warn("GPT Astra Token HUD could not start:",t.message));})();
